---
layout: default
title: Developer Diary
---

# {{PROJECT_NAME}} — Developer Diary

{{PROJECT_DESCRIPTION}}

{% if site.posts.size > 0 %}
{% for post in site.posts %}
- **{{ post.date | date: "%Y-%m-%d" }}** — [{{ post.title }}]({{ post.url | relative_url }})
{% endfor %}
{% else %}
_No entries yet._
{% endif %}

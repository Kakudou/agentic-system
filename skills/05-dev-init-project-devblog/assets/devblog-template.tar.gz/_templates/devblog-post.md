---
title: ""
date: YYYY-MM-DD HH:MM:SS +0000
layout: post
tags: []
# Optional evidence verdict for this entry: PASS, FAIL, or UNVERIFIED.
# Leave empty when the entry makes no verification claim.
verdict: ""
---

## Context

What forced this work?

## Change

What changed?

## Evidence

What was actually observed: tests, measurements, failures, or verification?

## Lessons

What knowledge should survive this implementation?

## Next

What remains intentionally unfinished?
